
function array1() {
    var number = [];
    for (let i = 1; i <= 100; i++) {
        number.push(i); 
        }
return number;
    }
alert(array1())
    console.log (array1);
    


